import random

# Function to generate a random worker
def generate_worker(worker_id):
    try:
        # Randomly assigning salary, gender, and employee id
        salary = random.randint(5000, 35000)
        gender = random.choice(["Male", "Female"])
        
        worker = {
            "worker_id": worker_id,
            "salary": salary,
            "gender": gender,
        }
        
        return worker
    except Exception as e:
        print(f"Error generating worker {worker_id}: {e}")
        return None

# Function to determine employee level based on salary and gender
def assign_employee_level(worker):
    try:
        salary = worker["salary"]
        gender = worker["gender"]
        
        # Assigning employee level based on salary and gender
        if 10000 < salary < 20000:
            level = "A1"
        elif 7500 < salary < 30000 and gender == "Female":
            level = "A5-F"
        else:
            level = "B"
        
        return level
    except Exception as e:
        print(f"Error assigning level to worker {worker['worker_id']}: {e}")
        return "Unknown"

# Function to generate and process 400 workers
def generate_payment_slips(num_workers=400):
    workers = []
    payment_slips = []

    # Generate workers
    for worker_id in range(1, num_workers + 1):
        worker = generate_worker(worker_id)
        
        if worker:
            workers.append(worker)
            
            # Assign employee level and prepare payment slip
            level = assign_employee_level(worker)
            payment_slips.append({
                "worker_id": worker["worker_id"],
                "salary": worker["salary"],
                "gender": worker["gender"],
                "employee_level": level,
            })
    
    # Print out payment slips (or process them further)
    for slip in payment_slips:
        print(f"Worker ID: {slip['worker_id']} | Salary: ${slip['salary']} | Gender: {slip['gender']} | Level: {slip['employee_level']}")

# Generate and process 400 workers
generate_payment_slips()

