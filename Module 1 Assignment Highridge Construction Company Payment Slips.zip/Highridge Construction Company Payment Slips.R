
R version 4.4.2 (2024-10-31 ucrt) -- "Pile of Leaves"
Copyright (C) 2024 The R Foundation for Statistical Computing
Platform: x86_64-w64-mingw32/x64

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # Generate 400 workers with random data
> set.seed(123)  # Set seed for reproducibility
> workers <- data.frame(
+   id = 1:400,
+   name = paste("Worker", 1:400),
+   salary = sample(5000:35000, 400, replace = TRUE),  # Random salary between 5000 and 35000
+   gender = sample(c("male", "female"), 400, replace = TRUE)  # Random gender
+ )
> 
> # Loop through each worker and generate payment slips
> for (i in 1:nrow(workers)) {
+   tryCatch({
+     # Get worker details
+     worker <- workers[i, ]
+     name <- worker$name
+     salary <- worker$salary
+     gender <- worker$gender
+     
+     # Initialize employee level
+     employee_level <- "Not Assigned"
+     
+     # Conditional logic to determine employee level
+     if (salary > 10000 & salary < 20000) {
+       employee_level <- "A1"
+     } else if (salary > 7500 & salary < 30000 & gender == "female") {
+       employee_level <- "A5-F"
+     }
+     
+     # Print payment slip
+     cat("Payment Slip for", name, ":\n")
+     cat("Salary:", salary, "\n")
+     cat("Employee Level:", employee_level, "\n")
+     cat(rep("-", 40), "\n")
+   }, error = function(e) {
+     cat("Error processing worker", workers$name[i], ":", e$message, "\n")
+   })
+ }
Payment Slip for Worker 1 :
Salary: 23846 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 2 :
Salary: 23894 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 3 :
Salary: 31802 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 4 :
Salary: 30101 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 5 :
Salary: 33866 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 6 :
Salary: 7985 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 7 :
Salary: 6841 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 8 :
Salary: 30717 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 9 :
Salary: 8370 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 10 :
Salary: 34924 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 11 :
Salary: 34939 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 12 :
Salary: 34709 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 13 :
Salary: 16637 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 14 :
Salary: 9760 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 15 :
Salary: 11745 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 16 :
Salary: 31202 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 17 :
Salary: 21127 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 18 :
Salary: 7756 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 19 :
Salary: 26490 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 20 :
Salary: 34786 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 21 :
Salary: 30528 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 22 :
Salary: 17635 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 23 :
Salary: 14208 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 24 :
Salary: 15204 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 25 :
Salary: 18666 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 26 :
Salary: 7887 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 27 :
Salary: 11169 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 28 :
Salary: 23950 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 29 :
Salary: 14641 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 30 :
Salary: 31365 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 31 :
Salary: 17498 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 32 :
Salary: 24363 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 33 :
Salary: 6613 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 34 :
Salary: 21938 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 35 :
Salary: 19182 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 36 :
Salary: 25852 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 37 :
Salary: 20179 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 38 :
Salary: 14358 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 39 :
Salary: 32167 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 40 :
Salary: 32113 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 41 :
Salary: 29172 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 42 :
Salary: 14990 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 43 :
Salary: 14096 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 44 :
Salary: 20272 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 45 :
Salary: 22430 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 46 :
Salary: 28450 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 47 :
Salary: 8003 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 48 :
Salary: 33980 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 49 :
Salary: 24590 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 50 :
Salary: 12988 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 51 :
Salary: 8994 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 52 :
Salary: 18535 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 53 :
Salary: 13357 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 54 :
Salary: 21600 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 55 :
Salary: 30889 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 56 :
Salary: 29540 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 57 :
Salary: 15820 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 58 :
Salary: 11215 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 59 :
Salary: 30163 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 60 :
Salary: 22982 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 61 :
Salary: 25620 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 62 :
Salary: 34393 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 63 :
Salary: 25320 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 64 :
Salary: 25472 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 65 :
Salary: 24290 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 66 :
Salary: 33824 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 67 :
Salary: 21677 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 68 :
Salary: 13468 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 69 :
Salary: 18774 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 70 :
Salary: 5040 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 71 :
Salary: 19425 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 72 :
Salary: 29891 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 73 :
Salary: 12390 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 74 :
Salary: 28055 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 75 :
Salary: 12283 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 76 :
Salary: 20965 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 77 :
Salary: 16013 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 78 :
Salary: 32370 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 79 :
Salary: 23887 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 80 :
Salary: 11741 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 81 :
Salary: 33501 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 82 :
Salary: 30758 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 83 :
Salary: 30327 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 84 :
Salary: 16472 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 85 :
Salary: 13565 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 86 :
Salary: 15033 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 87 :
Salary: 27512 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 88 :
Salary: 15273 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 89 :
Salary: 25995 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 90 :
Salary: 17300 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 91 :
Salary: 23500 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 92 :
Salary: 11133 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 93 :
Salary: 5754 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 94 :
Salary: 11552 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 95 :
Salary: 26811 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 96 :
Salary: 34784 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 97 :
Salary: 30581 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 98 :
Salary: 32160 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 99 :
Salary: 12126 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 100 :
Salary: 31914 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 101 :
Salary: 14639 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 102 :
Salary: 33527 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 103 :
Salary: 24741 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 104 :
Salary: 8979 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 105 :
Salary: 34342 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 106 :
Salary: 19456 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 107 :
Salary: 14325 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 108 :
Salary: 8229 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 109 :
Salary: 34759 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 110 :
Salary: 10602 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 111 :
Salary: 31509 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 112 :
Salary: 14692 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 113 :
Salary: 25959 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 114 :
Salary: 25166 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 115 :
Salary: 19402 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 116 :
Salary: 29214 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 117 :
Salary: 15105 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 118 :
Salary: 10966 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 119 :
Salary: 14300 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 120 :
Salary: 17452 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 121 :
Salary: 12815 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 122 :
Salary: 30650 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 123 :
Salary: 16337 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 124 :
Salary: 20537 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 125 :
Salary: 6385 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 126 :
Salary: 15475 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 127 :
Salary: 26089 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 128 :
Salary: 23761 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 129 :
Salary: 33798 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 130 :
Salary: 25427 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 131 :
Salary: 31835 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 132 :
Salary: 5685 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 133 :
Salary: 17048 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 134 :
Salary: 27461 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 135 :
Salary: 20149 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 136 :
Salary: 20669 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 137 :
Salary: 10026 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 138 :
Salary: 21103 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 139 :
Salary: 20213 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 140 :
Salary: 27770 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 141 :
Salary: 30422 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 142 :
Salary: 21151 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 143 :
Salary: 12280 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 144 :
Salary: 30558 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 145 :
Salary: 9714 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 146 :
Salary: 19214 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 147 :
Salary: 34148 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 148 :
Salary: 19286 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 149 :
Salary: 5150 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 150 :
Salary: 28193 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 151 :
Salary: 14829 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 152 :
Salary: 29557 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 153 :
Salary: 28294 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 154 :
Salary: 7207 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 155 :
Salary: 20750 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 156 :
Salary: 19490 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 157 :
Salary: 32049 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 158 :
Salary: 22412 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 159 :
Salary: 13517 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 160 :
Salary: 17047 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 161 :
Salary: 28831 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 162 :
Salary: 21159 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 163 :
Salary: 16028 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 164 :
Salary: 12734 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 165 :
Salary: 29394 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 166 :
Salary: 6955 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 167 :
Salary: 29555 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 168 :
Salary: 10357 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 169 :
Salary: 27267 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 170 :
Salary: 25476 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 171 :
Salary: 18650 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 172 :
Salary: 22368 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 173 :
Salary: 11182 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 174 :
Salary: 22369 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 175 :
Salary: 9232 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 176 :
Salary: 32078 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 177 :
Salary: 31337 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 178 :
Salary: 22967 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 179 :
Salary: 26068 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 180 :
Salary: 12863 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 181 :
Salary: 33659 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 182 :
Salary: 31662 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 183 :
Salary: 15435 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 184 :
Salary: 14984 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 185 :
Salary: 9775 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 186 :
Salary: 20645 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 187 :
Salary: 11643 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 188 :
Salary: 5984 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 189 :
Salary: 31383 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 190 :
Salary: 29919 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 191 :
Salary: 28861 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 192 :
Salary: 23890 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 193 :
Salary: 16183 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 194 :
Salary: 16283 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 195 :
Salary: 21578 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 196 :
Salary: 19172 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 197 :
Salary: 16427 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 198 :
Salary: 8123 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 199 :
Salary: 18163 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 200 :
Salary: 28061 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 201 :
Salary: 31800 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 202 :
Salary: 26033 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 203 :
Salary: 32450 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 204 :
Salary: 23515 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 205 :
Salary: 19968 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 206 :
Salary: 17214 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 207 :
Salary: 8463 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 208 :
Salary: 30901 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 209 :
Salary: 8948 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 210 :
Salary: 17993 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 211 :
Salary: 32242 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 212 :
Salary: 12756 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 213 :
Salary: 33077 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 214 :
Salary: 7757 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 215 :
Salary: 8832 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 216 :
Salary: 22095 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 217 :
Salary: 31027 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 218 :
Salary: 17959 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 219 :
Salary: 26753 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 220 :
Salary: 15019 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 221 :
Salary: 24884 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 222 :
Salary: 8068 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 223 :
Salary: 15637 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 224 :
Salary: 16252 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 225 :
Salary: 13719 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 226 :
Salary: 25438 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 227 :
Salary: 19716 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 228 :
Salary: 31144 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 229 :
Salary: 19857 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 230 :
Salary: 21856 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 231 :
Salary: 19535 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 232 :
Salary: 11097 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 233 :
Salary: 22532 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 234 :
Salary: 7036 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 235 :
Salary: 23696 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 236 :
Salary: 16014 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 237 :
Salary: 31502 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 238 :
Salary: 29124 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 239 :
Salary: 32899 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 240 :
Salary: 30033 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 241 :
Salary: 16415 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 242 :
Salary: 34502 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 243 :
Salary: 6077 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 244 :
Salary: 10014 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 245 :
Salary: 27041 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 246 :
Salary: 27762 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 247 :
Salary: 6312 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 248 :
Salary: 5184 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 249 :
Salary: 29316 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 250 :
Salary: 5412 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 251 :
Salary: 9722 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 252 :
Salary: 15761 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 253 :
Salary: 22716 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 254 :
Salary: 20413 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 255 :
Salary: 9874 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 256 :
Salary: 14752 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 257 :
Salary: 21947 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 258 :
Salary: 13985 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 259 :
Salary: 30990 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 260 :
Salary: 19744 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 261 :
Salary: 8798 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 262 :
Salary: 30945 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 263 :
Salary: 9255 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 264 :
Salary: 19803 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 265 :
Salary: 8580 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 266 :
Salary: 16159 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 267 :
Salary: 24512 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 268 :
Salary: 11600 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 269 :
Salary: 9712 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 270 :
Salary: 29932 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 271 :
Salary: 21662 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 272 :
Salary: 25749 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 273 :
Salary: 11789 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 274 :
Salary: 11490 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 275 :
Salary: 24584 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 276 :
Salary: 23649 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 277 :
Salary: 5617 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 278 :
Salary: 23288 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 279 :
Salary: 20033 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 280 :
Salary: 13528 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 281 :
Salary: 15265 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 282 :
Salary: 5538 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 283 :
Salary: 34652 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 284 :
Salary: 30531 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 285 :
Salary: 18977 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 286 :
Salary: 8624 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 287 :
Salary: 28251 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 288 :
Salary: 24845 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 289 :
Salary: 27001 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 290 :
Salary: 20581 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 291 :
Salary: 28198 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 292 :
Salary: 28388 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 293 :
Salary: 28184 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 294 :
Salary: 24391 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 295 :
Salary: 14636 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 296 :
Salary: 18368 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 297 :
Salary: 11803 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 298 :
Salary: 7210 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 299 :
Salary: 7285 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 300 :
Salary: 27176 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 301 :
Salary: 32201 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 302 :
Salary: 12683 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 303 :
Salary: 23761 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 304 :
Salary: 20584 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 305 :
Salary: 26892 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 306 :
Salary: 25596 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 307 :
Salary: 17935 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 308 :
Salary: 14270 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 309 :
Salary: 14432 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 310 :
Salary: 32180 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 311 :
Salary: 12825 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 312 :
Salary: 6705 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 313 :
Salary: 19750 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 314 :
Salary: 29262 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 315 :
Salary: 30448 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 316 :
Salary: 20023 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 317 :
Salary: 13080 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 318 :
Salary: 13948 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 319 :
Salary: 5987 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 320 :
Salary: 15686 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 321 :
Salary: 12988 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 322 :
Salary: 16060 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 323 :
Salary: 32454 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 324 :
Salary: 26190 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 325 :
Salary: 26971 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 326 :
Salary: 14425 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 327 :
Salary: 17636 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 328 :
Salary: 31000 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 329 :
Salary: 25192 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 330 :
Salary: 28809 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 331 :
Salary: 23608 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 332 :
Salary: 17673 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 333 :
Salary: 6164 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 334 :
Salary: 31647 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 335 :
Salary: 32646 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 336 :
Salary: 27466 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 337 :
Salary: 29017 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 338 :
Salary: 34825 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 339 :
Salary: 7212 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 340 :
Salary: 22995 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 341 :
Salary: 18688 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 342 :
Salary: 25236 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 343 :
Salary: 10564 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 344 :
Salary: 22093 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 345 :
Salary: 29425 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 346 :
Salary: 22641 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 347 :
Salary: 7469 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 348 :
Salary: 32131 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 349 :
Salary: 17143 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 350 :
Salary: 23495 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 351 :
Salary: 11223 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 352 :
Salary: 18794 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 353 :
Salary: 24418 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 354 :
Salary: 19810 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 355 :
Salary: 23722 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 356 :
Salary: 11908 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 357 :
Salary: 20702 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 358 :
Salary: 22730 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 359 :
Salary: 11622 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 360 :
Salary: 12727 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 361 :
Salary: 13982 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 362 :
Salary: 31562 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 363 :
Salary: 10000 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 364 :
Salary: 30916 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 365 :
Salary: 34478 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 366 :
Salary: 18533 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 367 :
Salary: 10406 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 368 :
Salary: 27237 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 369 :
Salary: 16848 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 370 :
Salary: 25771 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 371 :
Salary: 26729 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 372 :
Salary: 19101 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 373 :
Salary: 23091 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 374 :
Salary: 17584 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 375 :
Salary: 34531 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 376 :
Salary: 26084 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 377 :
Salary: 6834 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 378 :
Salary: 8110 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 379 :
Salary: 14452 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 380 :
Salary: 11308 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 381 :
Salary: 26098 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 382 :
Salary: 30632 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 383 :
Salary: 13274 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 384 :
Salary: 24851 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 385 :
Salary: 30441 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 386 :
Salary: 15516 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 387 :
Salary: 28760 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 388 :
Salary: 34694 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 389 :
Salary: 9171 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 390 :
Salary: 26597 
Employee Level: Not Assigned 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 391 :
Salary: 20389 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 392 :
Salary: 12384 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 393 :
Salary: 12089 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 394 :
Salary: 11517 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 395 :
Salary: 15562 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 396 :
Salary: 23546 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 397 :
Salary: 10496 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 398 :
Salary: 20185 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 399 :
Salary: 15847 
Employee Level: A1 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Payment Slip for Worker 400 :
Salary: 29016 
Employee Level: A5-F 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
> save.image("C:\\Users\\titil\\OneDrive\\Desktop\\Highridge Construction Company Payment Slips .R")
> 
